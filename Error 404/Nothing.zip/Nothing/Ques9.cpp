#include <iostream>
#include <string>
using namespace std;
class Person {
protected:
string name;
public:
Person(const string& n) : name(n) {}
virtual void display() {
cout << "Name: " << name << endl;
}
};
class Student : public Person {
protected:
string course;
int marks;
int year;
public:
Student(const string& n, const string& c, int m, int y) : Person(n),
course(c), marks(m), year(y) {}
void display(){
cout << "Student Details:" << endl;
Person::display();
cout << "Course: " << course << endl;
cout << "Marks: " << marks << endl;
cout << "Year: " << year << endl;
}
};
class Employee : public Person {
protected:
string department;
double salary;
public:
Employee(const string& n, const string& d, double s) : Person(n),
department(d), salary(s) {}
void display(){
cout << "Employee Details:" << endl;
Person::display();
cout << "Department: " << department << endl;
cout << "Salary: " << salary << endl;
}
};
int main() {
Student s("Harry", "Computer Science", 95, 2023);
Employee e("Potter", "Engineering", 50000);
Person* ptr1 = &s;
Person* ptr2 = &e;
ptr1->display();
cout << endl;
ptr2->display();
return 0;
}