#include <iostream>
#include <cstring>
using namespace std;
void showAddress(const char* str) {
cout << "Address of each character in the string:" << endl;
for (int i = 0; i < strlen(str); ++i) {
cout << str[i] << ": " << static_cast<const void*>(&str[i]) <<
endl;
}
}
void concatenateStrings(char* str1, char* str2) {
strcat(str1, str2);
}
int compareStrings(const char* str1, const char* str2) {
return strcmp(str1, str2);
}
int stringLength(const char* str) {
int length = 0;
while (*str != '\0') {
++length;
++str;
}
return length;
}
void toUpperCase(char* str) {
while (*str != '\0') {
if (*str >= 'a' && *str <= 'z') {
*str = *str - 32; // Convert to uppercase
}
++str;
}
}
void reverseString(char* str) {
int length = strlen(str);
for (int i = 0; i < length / 2; ++i) {
char temp = str[i];
str[i] = str[length - i - 1];
str[length - i - 1] = temp;
}
}
void insertString(char* mainStr, const char* insertStr, int position) {
int mainLength = strlen(mainStr);
int insertLength = strlen(insertStr);
// Shift characters to the right to make space for the inserted string
for (int i = mainLength; i >= position; --i) {
mainStr[i + insertLength] = mainStr[i];
}
// Insert the string
for (int i = 0; i < insertLength; ++i) {
mainStr[position + i] = insertStr[i];
}
}
int main() {
char str1[100], str2[100], option;
int position, result;
cout << "Enter string 1: ";
cin.getline(str1, 100);
cout << "Enter string 2: ";
cin.getline(str2, 100);
cout << "Choose an option:" << endl;
cout << "a. Show address of each character in string" << endl;
cout << "b. Concatenate two strings" << endl;
cout << "c. Compare two strings" << endl;
cout << "d. Calculate length of the string" << endl;
cout << "e. Convert all lowercase characters to uppercase" << endl;
cout << "f. Reverse the string" << endl;
cout << "g. Insert a string in another string at a user specified position" << endl;
cout << "Enter your choice: ";
cin >> option;
switch (option) {
case 'a':
showAddress(str1);
break;
case 'b':
concatenateStrings(str1, str2);
cout << "Concatenated string: " << str1 << endl;
break;
case 'c':
result = compareStrings(str1, str2);
if (result == 0)
cout << "Strings are equal." << endl;
else if (result < 0)
cout << "String 1 is less than string 2." << endl;
else
cout << "String 1 is greater than string 2." << endl;
break;
case 'd':
cout << "Length of string 1: " << stringLength(str1) << endl;
cout << "Length of string 2: " << stringLength(str2) << endl;
break;
case 'e':
toUpperCase(str1);
cout << "String 1 in uppercase: " << str1 << endl;
break;
case 'f':
reverseString(str1);
cout << "Reversed string 1: " << str1 << endl;
break;
case 'g':
cout << "Enter position to insert string: ";
cin >> position;
insertString(str1, str2, position);
cout << "String 1 after insertion: " << str1 << endl;
break;
default:
cout << "Invalid option!" << endl;
}
return 0;
}