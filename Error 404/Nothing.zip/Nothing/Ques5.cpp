#include<iostream>
using namespace std;
int main()
{
int n,temp;
int m;
cout<<"enter value of m and n";
cin>>m;
cin>>n;
int sum=m+n;
int a1[m];
int a2[n];
int a3[sum];
for(int i=0;i<m;i++)
{
cin>>a1[i];
}
for(int j=0;j<n;j++)
{
cin>>a2[j];
}
for(int i=0;i<m;i++)
{
a3[i]=a1[i];
}
for(int j=0;j<n;j++)
{
a3[m+j]=a2[j];
}
//Sorting the array
for(int i=0;i<sum;i++)
{
for(int j=i+1;j<sum;j++)
{
if(a3[j]<a3[i])
{
temp=a3[j];
a3[j]=a3[i];
a3[i]=temp;
}
}
}
cout<<"Merged array :"<<endl;
for(int i=0;i<sum;i++)
{
cout<<a3[i]<<" ";
}
}
