#include <iostream>
#include <cmath>
using namespace std;
class Triangle {
private:
float base;
float height;
float c;
public:
Triangle(float b, float h, float other) {
if (b <= 0 || h <= 0 || other <= 0) {
throw "Invalid";
}
if (b + h <= other || h + other <= b || other + b <= h) {
throw "Invalid";
}
base = b;
height = h;
c = other;
}
float area() {
float s = (base + height + c) / 2;
float area = sqrt(s * (s - base) * (s - height) * (s - c));
return area;
}
float area(float b, float h) {
return (b * h) / 2;
}
};
int main() {
try {
Triangle t1(0.0, 10.1, 10.5);
cout << "Area of the triangle: " << t1.area() << endl;
}
catch (const char* e) {
cout << "Exception: " << e << endl;
}
return 0;
}
