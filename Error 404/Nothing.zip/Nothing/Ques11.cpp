#include <fstream>
#include <iostream>
#include <string>
using namespace std;
class Student {
private:
int roll_no;
string name;
int marks;
int standard;
string year;
public:
void set_data(int r, string n, int m, int s, string y) {
roll_no = r;
name = n;
marks = m;
standard = s;
year = y;
}
void write_data(ofstream &out) {
out << roll_no << endl;
out << name << endl;
out << marks << endl;
out << standard << endl;
out << year << endl;
}
void read_data(ifstream &in) {
string st;
while(in.eof() == 0){
getline(in,st);
cout<<st<<endl;
}
}
};
int main() {
Student s1, s2, s3, s4, s5;
s1.set_data(1, "Harry", 98, 12, "First");
s2.set_data(2, "Rohan", 70, 12, "First");
s3.set_data(3, "Hammad", 60, 12, "First");
s4.set_data(4, "Rohit", 50, 12, "First");
s5.set_data(5, "Rohan", 70, 12, "First");
ofstream out("student.txt");
s1.write_data(out);
s2.write_data(out);
s3.write_data(out);
s4.write_data(out);
s5.write_data(out);
out.close();
ifstream in("student.txt");
s1.read_data(in);
s2.read_data(in);
s3.read_data(in);
s4.read_data(in);
s5.read_data(in);
in.close();
return 0;
}