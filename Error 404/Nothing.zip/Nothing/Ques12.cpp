#include <fstream>
#include <iostream>
using namespace std;
int main() {
ifstream in("sample2.txt");
ofstream out("sample.txt");
char c;
while (in.get(c)) {
if (!isspace(c)) {
out << c;
}
}
in.close();
out.close();
cout << "Whitespace removed and content copied successfully!";
return 0;
}
