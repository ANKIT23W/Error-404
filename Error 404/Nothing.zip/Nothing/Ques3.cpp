#include<iostream>
#include <string>
using namespace std;
int main()
{
string str;
int count=0;
cout<<"enter string";
cin>>str;
int n=str.length();
for(int j=65;j<90;j++)
{
for(int i=0;i<n;i++)
{
if(char(j)==str[i])
{
count++;
}
}
cout<<char(j)<<" "<<count<<endl;
count=0;
}
}