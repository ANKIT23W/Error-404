#include<iostream>
#include <math.h>
using namespace std;
int main()
{
double sum=0.0;
int n;
cout<<"enter number for which you want series";
cin>>n;
for(int i=1;i<=n;i++)
{
if(i%2==0)
{
sum-=(1/pow(i,i));
}
else
{
sum+=(1/pow(i,i));
}
}
cout<<"Sum of series = "<<sum<<endl;
}