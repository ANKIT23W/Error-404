#include <iostream>
using namespace std;
int main(){
int num =0;
cout<<"Enter the size of array: "<<endl;
cin>>num;
int arr[num];
cout<<"Enter the elements of array: "<<endl;
for(int i=0;i<num;i++){
cin>>arr[i];
}
for (int i=0;i<num;i++){
for(int j=i+1;j<num;j++){
if(arr[i]==arr[j]){
for(int k=j;k<num;k++){
arr[k]=arr[k+1];
}
num--;
j--;
}
}
}
cout<<"The array after removing duplicates: "<<endl;
for(int i=0;i<num;i++){
cout<<arr[i]<<" ";
}
return 0;
}