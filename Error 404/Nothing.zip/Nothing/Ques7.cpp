#include<iostream>
using namespace std;
//using normal function
int gcd(int a,int b)
{
int hcf=0;
if(a%b==0)
return b;
for(int i=1;i<b;i++)
{
if(a%i==0&&b%i==0)
{
hcf=i;
}
}
return hcf;
}
//using recursion
int gcdR(int a, int b)
{
if(a%b==0)
{
return b;
}
else
{
return gcdR(a,--b);
}
}
int main()
{
int x,y;
cout<<"enter x & y";
cin>>x;
cin>>y;
if(y>x)
{
int temp=x;
x=y;
y=temp;
}
cout<<"by normal function"<<gcd(x,y)<<endl;
cout<<"by recursion "<<gcdR(x,y);
}
