#include <iostream>
using namespace std;
class matrix {
public:
int rows;
int columns;
int X[10][10];
void sum(matrix, matrix);
void product(matrix, matrix);
void transpose();
void print();
void inputmatrix();
void setrc(int, int);
matrix();
};
matrix::matrix() {
rows = 0;
columns = 0;
for (int i = 0; i < 10; ++i) {
for (int j = 0; j < 10; ++j) {
X[i][j] = 0;
}
}
}
void matrix::sum(matrix m1, matrix m2) {
rows = m1.rows;
columns = m1.columns;
if (m1.rows != m2.rows || m1.columns != m2.columns) {
throw "Matrices are incompatible for addition";
}
rows = m1.rows;
columns = m1.columns;
for (int i = 0; i < rows; i++) {
for (int j = 0; j < columns; j++) {
X[i][j] = m1.X[i][j] + m2.X[i][j];
}
}
}
void matrix::product(matrix m1, matrix m2) {
if (m1.columns != m2.rows) {
throw "Matrices are incompatible for multiplication";
}
for (int i = 0; i < m1.rows; i++) {
for (int k = 0; k < m2.columns; k++) {
X[i][k] = 0;
for (int j = 0; j < m1.columns; j++) {
X[i][k] += m1.X[i][j] * m2.X[j][k];
}
}
}
}
void matrix::transpose() {
int result[columns][rows];
for (int i = 0; i < rows; i++) {
for (int j = 0; j < columns; j++) {
result[j][i] = X[i][j];
}
}
for (int i = 0; i < rows; i++) {
for (int j = 0; j < columns; j++) {
cout << result[i][j] << " ";
}
cout << endl;
}
}
void matrix::inputmatrix() {
cout << "ENTER THE ROWS OF THE MATRIX OF THIS OBJECT: ";
cin >> rows;
cout << "ENTER THE COLUMNS OF THE MATRIX OF THIS OBJECT: ";
cin >> columns;
for (int i = 0; i < rows; i++) {
for (int j = 0; j < columns; j++) {
cout << "ENTER THE ELEMENTS OF THE MATRIX SUBSEQUENTLY: ";
cin >> X[i][j];
}
}
}
void matrix::print() {
for (int i = 0; i < rows; i++) {
for (int j = 0; j < columns; j++) {
cout << X[i][j] << " ";
}
cout << endl;
}
}
void matrix::setrc(int r, int c) {
rows = r;
columns = c;
}
int main() {
matrix m1, m2, m3;
cout << "ENTER THE FIRST MATRIX: " << endl;
m1.inputmatrix();
cout << "ENTER THE SECOND MATRIX " << endl;
m2.inputmatrix();
cout << endl;
try {
m3.sum(m1, m2);
cout << "THE MATRIX AFTER THE SUM OF THE MATRIX 1 AND MATRIX 2 IS --"
<< endl;
m3.print();
} catch (const char *e) {
cout << "Exception: " << e << endl;
}
cout << endl;
try {
m3.product(m1, m2);
cout << "THE MATRIX AFTER THE PRODUCT OF THE MATRIX 1 AND MATRIX 2 IS--"
<< endl;
m3.print();
} catch (const char *e) {
cout << "Exception: " << e << endl;
}
cout << endl;
cout << "TRANPOSE OF MATRIX 1 IS --" << endl;
m1.transpose();
}
